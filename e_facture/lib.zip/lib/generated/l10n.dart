// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(
      _current != null,
      'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name =
        (locale.countryCode?.isEmpty ?? false)
            ? locale.languageCode
            : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(
      instance != null,
      'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Welcome`
  String get welcomeTitle {
    return Intl.message(
      'Welcome',
      name: 'welcomeTitle',
      desc: 'Home page title',
      args: [],
    );
  }

  /// `Email`
  String get generalEmail {
    return Intl.message(
      'Email',
      name: 'generalEmail',
      desc: 'Email label',
      args: [],
    );
  }

  /// `Password`
  String get generalPassword {
    return Intl.message(
      'Password',
      name: 'generalPassword',
      desc: 'Password label',
      args: [],
    );
  }

  /// `Validate`
  String get generalValidate {
    return Intl.message(
      'Validate',
      name: 'generalValidate',
      desc: 'Validate button',
      args: [],
    );
  }

  /// `Filter`
  String get generalFilter {
    return Intl.message(
      'Filter',
      name: 'generalFilter',
      desc: 'Filter label',
      args: [],
    );
  }

  /// `Search`
  String get generalSearch {
    return Intl.message(
      'Search',
      name: 'generalSearch',
      desc: 'Search label',
      args: [],
    );
  }

  /// `Download`
  String get generalDownload {
    return Intl.message(
      'Download',
      name: 'generalDownload',
      desc: 'Download label',
      args: [],
    );
  }

  /// `Total`
  String get generalTotal {
    return Intl.message(
      'Total',
      name: 'generalTotal',
      desc: 'Total label',
      args: [],
    );
  }

  /// `Date`
  String get generalDate {
    return Intl.message(
      'Date',
      name: 'generalDate',
      desc: 'Date label',
      args: [],
    );
  }

  /// `Amount`
  String get generalAmount {
    return Intl.message(
      'Amount',
      name: 'generalAmount',
      desc: 'Amount label',
      args: [],
    );
  }

  /// `Settings`
  String get generalSettings {
    return Intl.message(
      'Settings',
      name: 'generalSettings',
      desc: 'Label for settings',
      args: [],
    );
  }

  /// `Dark Mode`
  String get generalDarkMode {
    return Intl.message(
      'Dark Mode',
      name: 'generalDarkMode',
      desc: 'Dark mode label',
      args: [],
    );
  }

  /// `Language`
  String get generalLanguage {
    return Intl.message(
      'Language',
      name: 'generalLanguage',
      desc: 'Language label',
      args: [],
    );
  }

  /// `Logout`
  String get generalLogout {
    return Intl.message(
      'Logout',
      name: 'generalLogout',
      desc: 'Logout button',
      args: [],
    );
  }

  /// `Notifications`
  String get generalNotifications {
    return Intl.message(
      'Notifications',
      name: 'generalNotifications',
      desc: 'Notifications label',
      args: [],
    );
  }

  /// `Company`
  String get generalCompany {
    return Intl.message(
      'Company',
      name: 'generalCompany',
      desc: 'Company label',
      args: [],
    );
  }

  /// `ICE`
  String get generalIce {
    return Intl.message('ICE', name: 'generalIce', desc: 'ICE label', args: []);
  }

  /// `Social Reason`
  String get generalSocialReason {
    return Intl.message(
      'Social Reason',
      name: 'generalSocialReason',
      desc: 'Social reason label',
      args: [],
    );
  }

  /// `File`
  String get generalFile {
    return Intl.message(
      'File',
      name: 'generalFile',
      desc: 'File label',
      args: [],
    );
  }

  /// `Add`
  String get generalAdd {
    return Intl.message(
      'Add',
      name: 'generalAdd',
      desc: 'Add button',
      args: [],
    );
  }

  /// `Cancel`
  String get generalCancel {
    return Intl.message(
      'Cancel',
      name: 'generalCancel',
      desc: 'Cancel button',
      args: [],
    );
  }

  /// `Back`
  String get navigationBack {
    return Intl.message(
      'Back',
      name: 'navigationBack',
      desc: 'Back button',
      args: [],
    );
  }

  /// `User Dashboard`
  String get navigationDashboardUser {
    return Intl.message(
      'User Dashboard',
      name: 'navigationDashboardUser',
      desc: 'User dashboard label',
      args: [],
    );
  }

  /// `Admin Dashboard`
  String get navigationDashboardAdmin {
    return Intl.message(
      'Admin Dashboard',
      name: 'navigationDashboardAdmin',
      desc: 'Admin dashboard label',
      args: [],
    );
  }

  /// `Home`
  String get navigationHome {
    return Intl.message(
      'Home',
      name: 'navigationHome',
      desc: 'Home navigation label',
      args: [],
    );
  }

  /// `E-Invoice`
  String get homeTitle {
    return Intl.message(
      'E-Invoice',
      name: 'homeTitle',
      desc: 'Home page title',
      args: [],
    );
  }

  /// `e-Facture is an electronic invoice submission platform for SNRT suppliers.`
  String get homeDescription {
    return Intl.message(
      'e-Facture is an electronic invoice submission platform for SNRT suppliers.',
      name: 'homeDescription',
      desc: 'Home page description',
      args: [],
    );
  }

  /// `Don't have an account?`
  String get homeNoAccount {
    return Intl.message(
      'Don\'t have an account?',
      name: 'homeNoAccount',
      desc: 'No account text',
      args: [],
    );
  }

  /// `Sign up`
  String get homeSignup {
    return Intl.message(
      'Sign up',
      name: 'homeSignup',
      desc: 'Signup button',
      args: [],
    );
  }

  /// `Already have an account?`
  String get homeHaveAccount {
    return Intl.message(
      'Already have an account?',
      name: 'homeHaveAccount',
      desc: 'Have account text',
      args: [],
    );
  }

  /// `Log in`
  String get homeLogin {
    return Intl.message(
      'Log in',
      name: 'homeLogin',
      desc: 'Login button',
      args: [],
    );
  }

  /// `Registration Page`
  String get authSignupPageTitle {
    return Intl.message(
      'Registration Page',
      name: 'authSignupPageTitle',
      desc: 'Signup page title',
      args: [],
    );
  }

  /// `Login Page`
  String get authLoginPageTitle {
    return Intl.message(
      'Login Page',
      name: 'authLoginPageTitle',
      desc: 'Login page title',
      args: [],
    );
  }

  /// `Company Name`
  String get authCompanyName {
    return Intl.message(
      'Company Name',
      name: 'authCompanyName',
      desc: 'Company name field',
      args: [],
    );
  }

  /// `Enter your company name`
  String get authEnterCompanyName {
    return Intl.message(
      'Enter your company name',
      name: 'authEnterCompanyName',
      desc: 'Company name placeholder',
      args: [],
    );
  }

  /// `Enter ICE`
  String get authEnterIce {
    return Intl.message(
      'Enter ICE',
      name: 'authEnterIce',
      desc: 'ICE placeholder',
      args: [],
    );
  }

  /// `Enter your email`
  String get authEnterEmail {
    return Intl.message(
      'Enter your email',
      name: 'authEnterEmail',
      desc: 'Email placeholder',
      args: [],
    );
  }

  /// `Enter your password`
  String get authEnterPassword {
    return Intl.message(
      'Enter your password',
      name: 'authEnterPassword',
      desc: 'Password placeholder',
      args: [],
    );
  }

  /// `Sign up`
  String get authSignupButton {
    return Intl.message(
      'Sign up',
      name: 'authSignupButton',
      desc: 'Signup button',
      args: [],
    );
  }

  /// `An email has been sent to you to change your password.`
  String get authEmailPasswordReset {
    return Intl.message(
      'An email has been sent to you to change your password.',
      name: 'authEmailPasswordReset',
      desc: 'Password reset email sent',
      args: [],
    );
  }

  /// `Send link`
  String get authSendLink {
    return Intl.message(
      'Send link',
      name: 'authSendLink',
      desc: 'Send link button',
      args: [],
    );
  }

  /// `Old password`
  String get authOldPassword {
    return Intl.message(
      'Old password',
      name: 'authOldPassword',
      desc: 'Old password field',
      args: [],
    );
  }

  /// `Enter your old password`
  String get authEnterOldPassword {
    return Intl.message(
      'Enter your old password',
      name: 'authEnterOldPassword',
      desc: 'Old password placeholder',
      args: [],
    );
  }

  /// `New password`
  String get authNewPassword {
    return Intl.message(
      'New password',
      name: 'authNewPassword',
      desc: 'New password field',
      args: [],
    );
  }

  /// `Enter your new password`
  String get authEnterNewPassword {
    return Intl.message(
      'Enter your new password',
      name: 'authEnterNewPassword',
      desc: 'New password placeholder',
      args: [],
    );
  }

  /// `Confirm password`
  String get authConfirmPassword {
    return Intl.message(
      'Confirm password',
      name: 'authConfirmPassword',
      desc: 'Confirm password field',
      args: [],
    );
  }

  /// `Confirm your new password`
  String get authConfirmNewPassword {
    return Intl.message(
      'Confirm your new password',
      name: 'authConfirmNewPassword',
      desc: 'Confirm password placeholder',
      args: [],
    );
  }

  /// `Password changed successfully!`
  String get authPasswordChanged {
    return Intl.message(
      'Password changed successfully!',
      name: 'authPasswordChanged',
      desc: 'Password changed success message',
      args: [],
    );
  }

  /// `Change password`
  String get authChangePassword {
    return Intl.message(
      'Change password',
      name: 'authChangePassword',
      desc: 'Change password button',
      args: [],
    );
  }

  /// `First Login`
  String get authFirstLogin {
    return Intl.message(
      'First Login',
      name: 'authFirstLogin',
      desc: 'First login label',
      args: [],
    );
  }

  /// `Manage users`
  String get dashboardManageUsers {
    return Intl.message(
      'Manage users',
      name: 'dashboardManageUsers',
      desc: 'Manage users button',
      args: [],
    );
  }

  /// `View invoices`
  String get dashboardViewInvoices {
    return Intl.message(
      'View invoices',
      name: 'dashboardViewInvoices',
      desc: 'View invoices button',
      args: [],
    );
  }

  /// `Create invoice`
  String get dashboardCreateInvoice {
    return Intl.message(
      'Create invoice',
      name: 'dashboardCreateInvoice',
      desc: 'Create invoice button',
      args: [],
    );
  }

  /// `View my invoices`
  String get dashboardViewMyInvoices {
    return Intl.message(
      'View my invoices',
      name: 'dashboardViewMyInvoices',
      desc: 'View my invoices button',
      args: [],
    );
  }

  /// `Invoices Management (Admin)`
  String get adminInvoicesManagement {
    return Intl.message(
      'Invoices Management (Admin)',
      name: 'adminInvoicesManagement',
      desc: 'Admin invoices management title',
      args: [],
    );
  }

  /// `Users Management`
  String get adminUsersManagement {
    return Intl.message(
      'Users Management',
      name: 'adminUsersManagement',
      desc: 'Users management title',
      args: [],
    );
  }

  /// `Search by Company Name`
  String get adminSearchByCompany {
    return Intl.message(
      'Search by Company Name',
      name: 'adminSearchByCompany',
      desc: 'Search by company placeholder',
      args: [],
    );
  }

  /// `Company Name:`
  String get adminCompanyNameLabel {
    return Intl.message(
      'Company Name:',
      name: 'adminCompanyNameLabel',
      desc: 'Company name label',
      args: [],
    );
  }

  /// `ICE:`
  String get adminIceLabel {
    return Intl.message(
      'ICE:',
      name: 'adminIceLabel',
      desc: 'ICE label',
      args: [],
    );
  }

  /// `Email:`
  String get adminEmailLabel {
    return Intl.message(
      'Email:',
      name: 'adminEmailLabel',
      desc: 'Email label',
      args: [],
    );
  }

  /// `Invoices Submitted:`
  String get adminInvoicesSubmitted {
    return Intl.message(
      'Invoices Submitted:',
      name: 'adminInvoicesSubmitted',
      desc: 'Invoices submitted label',
      args: [],
    );
  }

  /// `View Invoice`
  String get adminViewInvoice {
    return Intl.message(
      'View Invoice',
      name: 'adminViewInvoice',
      desc: 'View invoice button',
      args: [],
    );
  }

  /// `Deactivate`
  String get adminDeactivate {
    return Intl.message(
      'Deactivate',
      name: 'adminDeactivate',
      desc: 'Deactivate button',
      args: [],
    );
  }

  /// `Account of {company} deactivated`
  String adminAccountDeactivated(String company) {
    return Intl.message(
      'Account of $company deactivated',
      name: 'adminAccountDeactivated',
      desc: 'Account deactivated message',
      args: [company],
    );
  }

  /// `Downloading {invoice}...`
  String adminDownloading(String invoice) {
    return Intl.message(
      'Downloading $invoice...',
      name: 'adminDownloading',
      desc: 'Downloading message',
      args: [invoice],
    );
  }

  /// `Create an Invoice`
  String get invoiceCreateInvoiceTitle {
    return Intl.message(
      'Create an Invoice',
      name: 'invoiceCreateInvoiceTitle',
      desc: 'Create invoice title',
      args: [],
    );
  }

  /// `Add a PDF file`
  String get invoiceAddPdf {
    return Intl.message(
      'Add a PDF file',
      name: 'invoiceAddPdf',
      desc: 'Add PDF button',
      args: [],
    );
  }

  /// `The file must be a PDF and < 2 MB.`
  String get invoiceFileRequirements {
    return Intl.message(
      'The file must be a PDF and < 2 MB.',
      name: 'invoiceFileRequirements',
      desc: 'File requirements message',
      args: [],
    );
  }

  /// `The amount must be greater than 5 million.`
  String get invoiceAmountRequirements {
    return Intl.message(
      'The amount must be greater than 5 million.',
      name: 'invoiceAmountRequirements',
      desc: 'Amount requirements message',
      args: [],
    );
  }

  /// `Add the invoice`
  String get invoiceAddInvoice {
    return Intl.message(
      'Add the invoice',
      name: 'invoiceAddInvoice',
      desc: 'Add invoice button',
      args: [],
    );
  }

  /// `PDF file selected: {filename}`
  String invoicePdfSelected(String filename) {
    return Intl.message(
      'PDF file selected: $filename',
      name: 'invoicePdfSelected',
      desc: 'PDF selected message',
      args: [filename],
    );
  }

  /// `Invoice History`
  String get invoiceInvoiceHistory {
    return Intl.message(
      'Invoice History',
      name: 'invoiceInvoiceHistory',
      desc: 'Invoice history title',
      args: [],
    );
  }

  /// `Search for an invoice...`
  String get invoiceSearchInvoice {
    return Intl.message(
      'Search for an invoice...',
      name: 'invoiceSearchInvoice',
      desc: 'Search invoice placeholder',
      args: [],
    );
  }

  /// `Date`
  String get invoiceDateFilter {
    return Intl.message(
      'Date',
      name: 'invoiceDateFilter',
      desc: 'Date filter label',
      args: [],
    );
  }

  /// `Amount`
  String get invoiceAmountFilter {
    return Intl.message(
      'Amount',
      name: 'invoiceAmountFilter',
      desc: 'Amount filter label',
      args: [],
    );
  }

  /// `All dates`
  String get invoiceAllDates {
    return Intl.message(
      'All dates',
      name: 'invoiceAllDates',
      desc: 'All dates option',
      args: [],
    );
  }

  /// `January`
  String get invoiceJanuary {
    return Intl.message(
      'January',
      name: 'invoiceJanuary',
      desc: 'January option',
      args: [],
    );
  }

  /// `February`
  String get invoiceFebruary {
    return Intl.message(
      'February',
      name: 'invoiceFebruary',
      desc: 'February option',
      args: [],
    );
  }

  /// `March`
  String get invoiceMarch {
    return Intl.message(
      'March',
      name: 'invoiceMarch',
      desc: 'March option',
      args: [],
    );
  }

  /// `All amounts`
  String get invoiceAllAmounts {
    return Intl.message(
      'All amounts',
      name: 'invoiceAllAmounts',
      desc: 'All amounts option',
      args: [],
    );
  }

  /// `Less than €2000`
  String get invoiceLessThan2000 {
    return Intl.message(
      'Less than €2000',
      name: 'invoiceLessThan2000',
      desc: 'Less than 2000€ option',
      args: [],
    );
  }

  /// `More than €2000`
  String get invoiceMoreThan2000 {
    return Intl.message(
      'More than €2000',
      name: 'invoiceMoreThan2000',
      desc: 'More than 2000€ option',
      args: [],
    );
  }

  /// `Arabic`
  String get languagesArabic {
    return Intl.message(
      'Arabic',
      name: 'languagesArabic',
      desc: 'Arabic language option',
      args: [],
    );
  }

  /// `French`
  String get languagesFrench {
    return Intl.message(
      'French',
      name: 'languagesFrench',
      desc: 'French language option',
      args: [],
    );
  }

  /// `English`
  String get languagesEnglish {
    return Intl.message(
      'English',
      name: 'languagesEnglish',
      desc: 'English language option',
      args: [],
    );
  }

  /// `Please enter a valid email.`
  String get errorsInvalidEmail {
    return Intl.message(
      'Please enter a valid email.',
      name: 'errorsInvalidEmail',
      desc: 'Invalid email error',
      args: [],
    );
  }

  /// `This field cannot be empty.`
  String get errorsEmptyField {
    return Intl.message(
      'This field cannot be empty.',
      name: 'errorsEmptyField',
      desc: 'Empty field error',
      args: [],
    );
  }

  /// `ICE must be numeric and contain between 8 and 15 digits.`
  String get errorsInvalidIce {
    return Intl.message(
      'ICE must be numeric and contain between 8 and 15 digits.',
      name: 'errorsInvalidIce',
      desc: '',
      args: [],
    );
  }

  /// `Company name must contain at least 3 characters.`
  String get errorsTooShortCompanyName {
    return Intl.message(
      'Company name must contain at least 3 characters.',
      name: 'errorsTooShortCompanyName',
      desc: '',
      args: [],
    );
  }

  /// `Company name cannot exceed 100 characters.`
  String get errorsTooLongCompanyName {
    return Intl.message(
      'Company name cannot exceed 100 characters.',
      name: 'errorsTooLongCompanyName',
      desc: '',
      args: [],
    );
  }

  /// `Error processing server response.`
  String get errorsServerResponseProcessing {
    return Intl.message(
      'Error processing server response.',
      name: 'errorsServerResponseProcessing',
      desc: '',
      args: [],
    );
  }

  /// `Empty response from server.`
  String get errorsEmptyServerResponse {
    return Intl.message(
      'Empty response from server.',
      name: 'errorsEmptyServerResponse',
      desc: '',
      args: [],
    );
  }

  /// `Registration failed.`
  String get errorsRegistrationFailed {
    return Intl.message(
      'Registration failed.',
      name: 'errorsRegistrationFailed',
      desc: '',
      args: [],
    );
  }

  /// `Registration successful! A temporary password has been sent to your email.`
  String get authRegistrationSuccessful {
    return Intl.message(
      'Registration successful! A temporary password has been sent to your email.',
      name: 'authRegistrationSuccessful',
      desc: '',
      args: [],
    );
  }

  /// `Login failed. Please check your credentials.`
  String get errorsLoginFailed {
    return Intl.message(
      'Login failed. Please check your credentials.',
      name: 'errorsLoginFailed',
      desc: 'Login failed error message',
      args: [],
    );
  }

  /// `Incorrect email or password.`
  String get errorsIncorrectCredentials {
    return Intl.message(
      'Incorrect email or password.',
      name: 'errorsIncorrectCredentials',
      desc: 'Incorrect email or password error message',
      args: [],
    );
  }

  /// `This account has been disabled. Please contact the administrator.`
  String get errorsAccountDisabled {
    return Intl.message(
      'This account has been disabled. Please contact the administrator.',
      name: 'errorsAccountDisabled',
      desc: 'Account disabled error message',
      args: [],
    );
  }

  /// `Login successful!`
  String get authLoginSuccessful {
    return Intl.message(
      'Login successful!',
      name: 'authLoginSuccessful',
      desc: 'Successful login message',
      args: [],
    );
  }

  /// `You need to change your password.`
  String get errorsPasswordChangeRequired {
    return Intl.message(
      'You need to change your password.',
      name: 'errorsPasswordChangeRequired',
      desc: 'Password change required message',
      args: [],
    );
  }

  /// `The provided password is not valid.`
  String get errorsInvalidPassword {
    return Intl.message(
      'The provided password is not valid.',
      name: 'errorsInvalidPassword',
      desc: 'Invalid password error message',
      args: [],
    );
  }

  /// `A new temporary password has been sent to your email address.`
  String get errorsPasswordResetSuccess {
    return Intl.message(
      'A new temporary password has been sent to your email address.',
      name: 'errorsPasswordResetSuccess',
      desc: 'Password reset success message',
      args: [],
    );
  }

  /// `Server error during login.`
  String get errorsServerLoginError {
    return Intl.message(
      'Server error during login.',
      name: 'errorsServerLoginError',
      desc: 'Server login error message',
      args: [],
    );
  }

  /// `Log In`
  String get authLoginButton {
    return Intl.message(
      'Log In',
      name: 'authLoginButton',
      desc: 'Login button',
      args: [],
    );
  }

  /// `Forgot Password?`
  String get authForgotPassword {
    return Intl.message(
      'Forgot Password?',
      name: 'authForgotPassword',
      desc: 'Link to reset password',
      args: [],
    );
  }

  /// `Email`
  String get authEmail {
    return Intl.message(
      'Email',
      name: 'authEmail',
      desc: 'Email field',
      args: [],
    );
  }

  /// `Password`
  String get authPassword {
    return Intl.message(
      'Password',
      name: 'authPassword',
      desc: 'Password field',
      args: [],
    );
  }

  /// `Don't have an account? Sign up now.`
  String get authRegisterMessage {
    return Intl.message(
      'Don\'t have an account? Sign up now.',
      name: 'authRegisterMessage',
      desc: 'Message for the user who doesn\'t have an account',
      args: [],
    );
  }

  /// `Already have an account? Log in.`
  String get authLoginMessage {
    return Intl.message(
      'Already have an account? Log in.',
      name: 'authLoginMessage',
      desc: 'Message for the user who has an account',
      args: [],
    );
  }

  /// `Log Out`
  String get authLogoutButton {
    return Intl.message(
      'Log Out',
      name: 'authLogoutButton',
      desc: 'Logout button',
      args: [],
    );
  }

  /// `Password Strength`
  String get authPasswordStrength {
    return Intl.message(
      'Password Strength',
      name: 'authPasswordStrength',
      desc: 'Password strength indicator',
      args: [],
    );
  }

  /// `Passwords do not match.`
  String get authPasswordMismatch {
    return Intl.message(
      'Passwords do not match.',
      name: 'authPasswordMismatch',
      desc: 'Message when passwords don\'t match',
      args: [],
    );
  }

  /// `Invalid email.`
  String get authInvalidEmail {
    return Intl.message(
      'Invalid email.',
      name: 'authInvalidEmail',
      desc: 'Message when the email is invalid',
      args: [],
    );
  }

  /// `Email is already in use.`
  String get authEmailAlreadyInUse {
    return Intl.message(
      'Email is already in use.',
      name: 'authEmailAlreadyInUse',
      desc: 'Message when the email is already taken',
      args: [],
    );
  }

  /// `Error fetching invoices.`
  String get errorFetchingInvoices {
    return Intl.message(
      'Error fetching invoices.',
      name: 'errorFetchingInvoices',
      desc: '',
      args: [],
    );
  }

  /// `No invoices available.`
  String get noInvoicesAvailable {
    return Intl.message(
      'No invoices available.',
      name: 'noInvoicesAvailable',
      desc: '',
      args: [],
    );
  }

  /// `My Invoices`
  String get myInvoices {
    return Intl.message('My Invoices', name: 'myInvoices', desc: '', args: []);
  }

  /// `Loading...`
  String get loading {
    return Intl.message('Loading...', name: 'loading', desc: '', args: []);
  }

  /// `My Invoices`
  String get userInvoicesTitle {
    return Intl.message(
      'My Invoices',
      name: 'userInvoicesTitle',
      desc: 'Title of the user invoices page',
      args: [],
    );
  }

  /// `Error: {error}`
  String errorMessage(Object error) {
    return Intl.message(
      'Error: $error',
      name: 'errorMessage',
      desc: 'Message displayed when an error occurs',
      args: [error],
    );
  }

  /// `ID`
  String get invoiceID {
    return Intl.message(
      'ID',
      name: 'invoiceID',
      desc: 'Invoice ID label',
      args: [],
    );
  }

  /// `Amount`
  String get invoiceAmount {
    return Intl.message(
      'Amount',
      name: 'invoiceAmount',
      desc: 'Invoice amount label',
      args: [],
    );
  }

  /// `Date`
  String get invoiceDate {
    return Intl.message(
      'Date',
      name: 'invoiceDate',
      desc: 'Invoice date label',
      args: [],
    );
  }

  /// `Download`
  String get invoiceDownload {
    return Intl.message(
      'Download',
      name: 'invoiceDownload',
      desc: 'Download button for invoice',
      args: [],
    );
  }

  /// `Statistics`
  String get statisticsTitle {
    return Intl.message(
      'Statistics',
      name: 'statisticsTitle',
      desc: 'Title for the section displaying invoice statistics',
      args: [],
    );
  }

  /// `Invoice Count`
  String get invoiceCount {
    return Intl.message(
      'Invoice Count',
      name: 'invoiceCount',
      desc: 'Indicates the total number of submitted invoices',
      args: [],
    );
  }

  /// `Total Amount`
  String get invoiceTotal {
    return Intl.message(
      'Total Amount',
      name: 'invoiceTotal',
      desc: 'Indicates the total amount of submitted invoices',
      args: [],
    );
  }

  /// `DH`
  String get currencySymbol {
    return Intl.message('DH', name: 'currencySymbol', desc: '', args: []);
  }

  /// `Admin Dashboard`
  String get adminDashboardTitle {
    return Intl.message(
      'Admin Dashboard',
      name: 'adminDashboardTitle',
      desc: '',
      args: [],
    );
  }

  /// `Manage users and view all invoices.`
  String get adminDashboardDescription {
    return Intl.message(
      'Manage users and view all invoices.',
      name: 'adminDashboardDescription',
      desc: '',
      args: [],
    );
  }

  /// `Manage Users`
  String get adminManageUsers {
    return Intl.message(
      'Manage Users',
      name: 'adminManageUsers',
      desc: '',
      args: [],
    );
  }

  /// `View All Invoices`
  String get adminViewInvoices {
    return Intl.message(
      'View All Invoices',
      name: 'adminViewInvoices',
      desc: '',
      args: [],
    );
  }

  /// `The new password cannot be the same as the old one.`
  String get authSameOldAndNewPassword {
    return Intl.message(
      'The new password cannot be the same as the old one.',
      name: 'authSameOldAndNewPassword',
      desc: '',
      args: [],
    );
  }

  /// `Password is too weak. It must contain at least 8 characters, an uppercase letter, a lowercase letter, and a digit.`
  String get authWeakPassword {
    return Intl.message(
      'Password is too weak. It must contain at least 8 characters, an uppercase letter, a lowercase letter, and a digit.',
      name: 'authWeakPassword',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
      Locale.fromSubtags(languageCode: 'fr'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
